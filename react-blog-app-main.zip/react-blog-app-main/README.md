# Features
* Fetching data based on id
* Listing data from an API

# Images
![screencapture-localhost-3000-2023-08-19-00_54_45](https://github.com/girayselcuk/react-blog-app/assets/80980937/53048cb0-a3ec-4667-b691-add284e85009)
<br>
![screencapture-localhost-3000-detail-1-2023-08-19-00_54_56](https://github.com/girayselcuk/react-blog-app/assets/80980937/fda096cc-1568-4032-b25a-3a407c86da4c)



